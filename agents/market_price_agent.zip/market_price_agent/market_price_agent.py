import requests

def get_market_prices(crop, state):
    """
    Get market prices for a crop in a state.
    """
    print(f"Searching market prices for {crop} in {state}...")

    # Market-data request will go here later
    return None


def main():
    print("\n💰 SMART FARMER - MARKET PRICE AGENT")
    print("------------------------------------")

    crop = input("Enter crop: ").strip()
    state = input("Enter state: ").strip()

    result = get_market_prices(crop, state)

    if result:
        print(result)
    else:
        print("\n❌ No market data found.")


if __name__ == "__main__":
    main()