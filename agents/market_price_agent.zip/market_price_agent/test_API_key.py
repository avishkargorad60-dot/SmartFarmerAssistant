import os
import requests

API_KEY = os.environ.get("DATA_GOV_API_KEY")

print("API key loaded:", bool(API_KEY))

if not API_KEY:
    print("❌ API key missing")
    raise SystemExit

url = "https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070"

params = {
    "api-key": API_KEY,
    "format": "json",
    "limit": 1
}

try:
    print("Connecting to data.gov.in...")

    response = requests.get(
        url,
        params=params,
        timeout=(10, 90)
    )

    print("Status code:", response.status_code)

    print("\nResponse:")
    print(response.text[:2000])

except requests.exceptions.Timeout:
    print("❌ Server response timed out after 90 seconds.")

except requests.exceptions.RequestException as error:
    print("❌ Request failed:")
    print(error)